export class Employee {
    employeeId:number;
}
