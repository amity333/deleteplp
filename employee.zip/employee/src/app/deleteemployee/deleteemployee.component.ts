import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-deleteemployee',
  templateUrl: './deleteemployee.component.html',
  styleUrls: ['./deleteemployee.component.css']
})
export class DeleteemployeeComponent implements OnInit {
  del:String;
  submitted:boolean;
  constructor(private empService:EmployeeService) { }
  ngOnInit() {
  }

  deleteEmployee(id: number){
    this.submitted=true;
    this.empService.deleteEmployee(id).subscribe(() =>this.del="Employee deleted Successfully!" );
  }
}
