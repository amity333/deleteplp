package com.cg.ems.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="employeetest")
public class Employee 
{
	
	
	@Id
	@Column(name="id")
	private int empId;
	
	@NotEmpty(message="Employee Name is mandatory")
	@Column(name="name")
	private String empName;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}

	public Employee(@NotEmpty(message = "Employee id is  Mandatory") int empId,
			@NotEmpty(message = "Employee Name is mandatory") String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
