package com.cg.ems.service;

import org.springframework.stereotype.Service;

@Service
public interface EmployeeService {
	public void deleteEmployee(int unm);
}
