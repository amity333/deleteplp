package com.cg.ems.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ems.dto.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {

	//@Modifying
	//@Query("DELETE FROM Employee emp  WHERE emp.empId=:unm")
	//public void deleteProduct(@Param("unm")int unm);
}
