package com.cg.ems.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.service.EmployeeService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class EmployeeRestController {
	@Autowired
	EmployeeService empser;
	
	@DeleteMapping(value="/employee/delete/{unm}")
	public String deleteEmployee(@PathVariable("unm") int unm)
	{
		System.out.println(unm);
		empser.deleteEmployee(unm);
		return String.valueOf(unm)+"deleted";
	}
}
