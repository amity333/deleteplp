package com.cg.ems.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.dao.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository emprepo;
	@Override
	public void deleteEmployee(int unm) {
		//System.out.println("In service");
		//emprepo.deleteProduct(unm);
		emprepo.deleteById(unm);
	}

}
